-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `migrate-source` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `migrate-source`;

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` varchar(1000) NOT NULL,
  `city` varchar(255) NOT NULL,
  `site_url` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `pages` (`id`, `title`, `body`, `city`, `site_url`, `state`, `site_name`, `keywords`, `created_date`) VALUES
(1,	'Hello world',	'Hello world body',	'Delhi',	'https://google.com',	'Delhi',	'Google',	'home,example1',	'2016-11-05 08:30:53'),
(2,	'Amazing page',	'This is body of amazing page.',	'Ahmedabad',	'https://facebook.com',	'Gujarat',	'Facebook',	'social, page',	'2016-11-05 08:02:26');

-- 2016-11-05 08:38:36
